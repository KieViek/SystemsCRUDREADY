package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.modelo.Alter;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

//List View
public class Alters extends AppCompatActivity {

    //Strings
    private EditText metNombreAlter;
    private EditText metGeneroAlter;
    private EditText metEspecieAlter;

    //Botones
    private Button mbtnRegistrarAlter;
    private Button mbtnListarAlter;

    //Firebase
    DatabaseReference mDatabase;
    FirebaseDatabase mFireBaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alters);
        inciarFirebase();
    }

    public void registrarAlter(View v) {
        metNombreAlter = (EditText) findViewById(R.id.etNombreAlter);
        metGeneroAlter = (EditText) findViewById(R.id.etGeneroAlter);
        metEspecieAlter = (EditText) findViewById(R.id.etEspecieAlter);

        String nombreAlter = metNombreAlter.getText().toString();
        String generoAlter = metGeneroAlter.getText().toString();
        String especieAlter = metEspecieAlter.getText().toString();

        //Crear Objeto
        Alter alt = new Alter();
        alt.setNombre(nombreAlter);
        alt.setEspecie(especieAlter);
        alt.setGenero(generoAlter);

        //Insertar en Firebase
        mDatabase.child("Alter").child(nombreAlter).setValue(alt);
    }

    public void inciarFirebase(){
        FirebaseApp.initializeApp(this);
        mFireBaseDatabase = FirebaseDatabase.getInstance();
        mDatabase = mFireBaseDatabase.getReference();
    }

    public void goListado(View v){
        Intent i = new Intent(getApplicationContext(),ListadoAlters.class);
        startActivity(i);
    }


}